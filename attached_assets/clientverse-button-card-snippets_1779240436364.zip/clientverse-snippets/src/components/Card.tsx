import * as React from "react";
import { ButtonLink } from "./Button";

type CardVariant =
  | "feature"
  | "trust"
  | "dashboard"
  | "pricing"
  | "pricingFeatured"
  | "objection"
  | "case";

type CardProps = React.HTMLAttributes<HTMLElement> & {
  as?: "article" | "section" | "div";
  variant?: CardVariant;
  interactive?: boolean;
};

type CardHeaderProps = {
  label?: string;
  title: string;
  eyebrow?: React.ReactNode;
  children?: React.ReactNode;
};

type FeatureCardProps = {
  label: string;
  title: string;
  copy: string;
  badge?: string;
  icon?: React.ReactNode;
  href?: string;
  ctaLabel?: string;
};

type TrustCardProps = {
  label?: string;
  title: string;
  proof: string;
  badge?: string;
};

type DashboardCardProps = {
  label: string;
  title: string;
  metric: string;
  metricLabel: string;
  context: string;
  status?: "connected" | "active" | "attention" | "risk";
};

type PricingCardProps = {
  tier: string;
  fit: string;
  price: string;
  features: string[];
  featured?: boolean;
  ctaHref: string;
  ctaLabel?: string;
  badge?: string;
};

type ObjectionCardProps = {
  objection: string;
  answer: string;
  proofNote?: string;
};

type CaseCardProps = {
  industry: string;
  title: string;
  problem: string;
  intervention: string;
  result: string;
  href?: string;
};

function cx(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

const variantClass: Record<CardVariant, string> = {
  feature: "cv-card--feature",
  trust: "cv-card--trust",
  dashboard: "cv-card--dashboard",
  pricing: "cv-card--pricing",
  pricingFeatured: "cv-card--pricing cv-card--pricing-featured",
  objection: "cv-card--objection",
  case: "cv-card--case",
};

export function Card({
  as: Component = "article",
  variant = "feature",
  interactive = false,
  className,
  children,
  ...props
}: CardProps) {
  return (
    <Component
      className={cx(
        "cv-card",
        variantClass[variant],
        interactive && "cv-card--interactive",
        className
      )}
      {...props}
    >
      {children}
    </Component>
  );
}

export function CardBody({
  className,
  children,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={cx("cv-card__body", className)} {...props}>
      {children}
    </div>
  );
}

export function CardHeader({ label, title, eyebrow, children }: CardHeaderProps) {
  return (
    <>
      {eyebrow ? <div className="cv-card__badge">{eyebrow}</div> : null}
      {label ? <p className="cv-card__label">{label}</p> : null}
      <h3 className="cv-card__title">{title}</h3>
      {children}
    </>
  );
}

export function FeatureCard({
  label,
  title,
  copy,
  badge,
  icon,
  href,
  ctaLabel = "Map This Workflow",
}: FeatureCardProps) {
  return (
    <Card variant="feature" interactive={Boolean(href)}>
      <CardBody>
        {badge ? <span className="cv-card__badge">{badge}</span> : null}
        {icon ? <div aria-hidden="true" style={{ marginBottom: "1rem" }}>{icon}</div> : null}
        <CardHeader label={label} title={title} />
        <p className="cv-card__copy">{copy}</p>
        {href ? (
          <div className="cv-card__actions">
            <ButtonLink href={href} variant="secondary" size="sm">
              {ctaLabel}
            </ButtonLink>
          </div>
        ) : null}
      </CardBody>
    </Card>
  );
}

export function TrustCard({
  label = "// ENTERPRISE TRUST",
  title,
  proof,
  badge,
}: TrustCardProps) {
  return (
    <Card variant="trust">
      <CardBody>
        {badge ? <span className="cv-card__badge">{badge}</span> : null}
        <CardHeader label={label} title={title} />
        <p className="cv-card__copy">{proof}</p>
      </CardBody>
    </Card>
  );
}

export function DashboardCard({
  label,
  title,
  metric,
  metricLabel,
  context,
  status = "active",
}: DashboardCardProps) {
  const statusText = {
    connected: "Connected",
    active: "Active",
    attention: "Attention",
    risk: "Risk detected",
  }[status];

  return (
    <Card variant="dashboard">
      <CardBody>
        <span className="cv-card__badge">{statusText}</span>
        <CardHeader label={label} title={title} />
        <div className="cv-card-metric" aria-label={`${metricLabel}: ${metric}`}>
          <span className="cv-card-metric__value">{metric}</span>
          <span className="cv-card-metric__label">{metricLabel}</span>
        </div>
        <p className="cv-card__meta">{context}</p>
      </CardBody>
    </Card>
  );
}

export function PricingCard({
  tier,
  fit,
  price,
  features,
  featured = false,
  ctaHref,
  ctaLabel = featured ? "Map the Right Tier" : "View Operating Scope",
  badge,
}: PricingCardProps) {
  return (
    <Card variant={featured ? "pricingFeatured" : "pricing"}>
      <CardBody>
        {badge ? <span className="cv-card__badge">{badge}</span> : null}
        <CardHeader label="// OPERATING TIER" title={tier} />
        <p className="cv-card__copy">{fit}</p>
        <div className="cv-card-metric" aria-label={`Price or scope: ${price}`}>
          <span className="cv-card-metric__value">{price}</span>
        </div>
        <ul className="cv-pricing-list">
          {features.slice(0, 8).map((feature) => (
            <li key={feature}>{feature}</li>
          ))}
        </ul>
        <div className="cv-card__actions">
          <ButtonLink
            href={ctaHref}
            variant={featured ? "primary" : "secondary"}
            fullWidth
          >
            {ctaLabel}
          </ButtonLink>
        </div>
      </CardBody>
    </Card>
  );
}

export function ObjectionCard({ objection, answer, proofNote }: ObjectionCardProps) {
  return (
    <Card variant="objection">
      <CardBody>
        <CardHeader label="// OBJECTION REMOVED" title={objection} />
        <p className="cv-card__copy">{answer}</p>
        {proofNote ? <p className="cv-card__meta">{proofNote}</p> : null}
      </CardBody>
    </Card>
  );
}

export function CaseCard({
  industry,
  title,
  problem,
  intervention,
  result,
  href,
}: CaseCardProps) {
  return (
    <Card variant="case" interactive={Boolean(href)}>
      <CardBody>
        <CardHeader label={industry} title={title} />
        <p className="cv-card__copy"><strong>Problem:</strong> {problem}</p>
        <p className="cv-card__copy"><strong>Intervention:</strong> {intervention}</p>
        <p className="cv-card__meta"><strong>Result:</strong> {result}</p>
        {href ? (
          <div className="cv-card__actions">
            <ButtonLink href={href} variant="secondary" size="sm">
              Build a Similar Recovery Plan
            </ButtonLink>
          </div>
        ) : null}
      </CardBody>
    </Card>
  );
}

export type {
  CardProps,
  CardVariant,
  FeatureCardProps,
  TrustCardProps,
  DashboardCardProps,
  PricingCardProps,
  ObjectionCardProps,
  CaseCardProps,
};
