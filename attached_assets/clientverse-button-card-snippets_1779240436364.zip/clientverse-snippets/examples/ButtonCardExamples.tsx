import "../src/styles/clientverse-ui.css";
import {
  Button,
  ButtonLink,
  clientVerseCtaCopy,
  FeatureCard,
  TrustCard,
  DashboardCard,
  PricingCard,
  ObjectionCard,
  CaseCard,
} from "../src/components";

export function ClientVerseButtonExamples() {
  return (
    <section aria-labelledby="button-examples-title" style={{ display: "grid", gap: "1rem" }}>
      <h2 id="button-examples-title">ClientVerse Button Examples</h2>

      <div style={{ display: "flex", flexWrap: "wrap", gap: "0.75rem" }}>
        <ButtonLink href="/audit" variant="primary" size="lg" mobileFull>
          {clientVerseCtaCopy.primaryAudit}
        </ButtonLink>

        <ButtonLink href="/pricing" variant="secondary" size="lg" mobileFull>
          {clientVerseCtaCopy.pricingSecondary}
        </ButtonLink>

        <Button variant="ghost">Review Use Cases</Button>

        <Button variant="icon" aria-label="Open workflow settings">
          <svg
            aria-hidden="true"
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M12 15.5A3.5 3.5 0 1 0 12 8a3.5 3.5 0 0 0 0 7.5Z" />
            <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06A1.65 1.65 0 0 0 15 19.4a1.65 1.65 0 0 0-1 .6 1.65 1.65 0 0 0-.4 1.08V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.5-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-.6A1.65 1.65 0 0 0 10.4 3V3a2 2 0 1 1 4 0v.09A1.65 1.65 0 0 0 15 4.6a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.36.63.92 1 1.6 1H21a2 2 0 1 1 0 4h-.09A1.65 1.65 0 0 0 19.4 15Z" />
          </svg>
        </Button>

        <Button variant="destructive">Revoke Integration</Button>
      </div>
    </section>
  );
}

export function ClientVerseCardExamples() {
  return (
    <section
      aria-labelledby="card-examples-title"
      style={{
        display: "grid",
        gap: "1.25rem",
        gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
      }}
    >
      <h2 id="card-examples-title" style={{ gridColumn: "1 / -1" }}>
        ClientVerse Card Examples
      </h2>

      <FeatureCard
        label="// RESPONSE CONTROL"
        title="Route qualified leads before response windows collapse."
        copy="ClientVerse identifies high-intent lead events, routes them into the correct follow-up path, and keeps the booking workflow visible to operators."
        badge="AI FOLLOW-UP"
        href="/services/response-control"
      />

      <TrustCard
        title="Built for businesses where response speed directly affects revenue."
        proof="The system is structured around audit, deployment, monitoring, and optimization rather than one-off automation experiments."
        badge="ENTERPRISE-READY"
      />

      <DashboardCard
        label="// LIVE OPERATIONS"
        title="Lead response system"
        metric="02:14"
        metricLabel="avg response window"
        context="Connected to booking flow · Last sync completed 2 minutes ago."
        status="connected"
      />

      <PricingCard
        tier="Growth Command"
        fit="For teams that need AI follow-up, booking visibility, and revenue workflow control across multiple lead sources."
        price="$1,500+"
        featured
        badge="RECOMMENDED"
        ctaHref="/pricing/growth-command"
        features={[
          "Revenue workflow audit",
          "Lead capture and routing map",
          "AI follow-up deployment",
          "Booking and no-show recovery paths",
          "Dashboard visibility layer",
          "Monthly optimization review",
        ]}
      />

      <ObjectionCard
        objection="Will this replace our current CRM?"
        answer="No. ClientVerse is designed to operate as a controlled automation and visibility layer around the systems your team already uses."
        proofNote="The audit identifies which tools stay, which workflows need repair, and where automation should be deployed first."
      />

      <CaseCard
        industry="LOCAL SERVICE OPERATIONS"
        title="Recovered missed-call follow-up without adding headcount."
        problem="Qualified inquiries were arriving across disconnected channels with inconsistent response ownership."
        intervention="ClientVerse mapped the lead path, deployed AI-assisted follow-up, and added operator visibility over booking status."
        result="The business gained a controlled response workflow and clearer accountability across lead sources."
        href="/case-studies/missed-call-recovery"
      />
    </section>
  );
}
