# ClientVerse Button and Card Snippets

**Purpose:** This package converts the ClientVerse SaaS Stylebook’s button and card rules into reusable CSS and React/TypeScript snippets. It is designed for direct use in a SaaS codebase while preserving the ClientVerse hierarchy: **amber owns primary action, navy owns authority, red owns loss or destructive behavior, green owns verified success, and neutrals own the interface**.

## Included Files

| File | Purpose |
|---|---|
| `src/styles/clientverse-ui.css` | ClientVerse color tokens, radius tokens, shadows, button classes, card classes, responsive behavior, and reduced-motion rules. |
| `src/components/Button.tsx` | Reusable `Button` and `ButtonLink` components with primary, secondary, inverse, ghost, icon, and destructive variants. |
| `src/components/Card.tsx` | Reusable base card plus feature, trust, dashboard, pricing, objection, and case-study card components. |
| `src/components/index.ts` | Export barrel for clean imports. |
| `examples/ButtonCardExamples.tsx` | Realistic usage examples for SaaS pages, pricing sections, dashboard proof, and CRO-oriented cards. |

## Installation Pattern

Copy the `src/styles` and `src/components` folders into your application. Import the CSS file once near your app root.

```tsx
import "./styles/clientverse-ui.css";
```

Then import components where needed.

```tsx
import { ButtonLink, FeatureCard, PricingCard } from "./components";
```

## Button Rules Implemented

| Variant | Stylebook Rule | Component Variant |
|---|---|---|
| Primary | Amber fill, navy text, 10px radius, 48–56px height, 600 weight. | `variant="primary"` |
| Secondary | Transparent or navy outline, amber hover border. | `variant="secondary"` |
| Secondary inverse | Dark-section outline button with inverse text and amber hover border. | `variant="secondaryInverse"` |
| Ghost | Minimal text or soft background for navigation and low-priority actions. | `variant="ghost"` |
| Icon | 40–44px utility control with accessible label. | `variant="icon"` |
| Destructive | Red text or outline for remove, delete, revoke, or cancel actions. | `variant="destructive"` |

## Card Rules Implemented

| Card Type | Stylebook Purpose | Component |
|---|---|---|
| Feature card | Explain one capability without turning the card into a brochure. | `FeatureCard` |
| Trust card | Reduce buyer risk and communicate enterprise readiness. | `TrustCard` |
| Dashboard card | Show a believable operating state, metric, timestamp, or context. | `DashboardCard` |
| Pricing card | Help the buyer self-identify by scope and operating complexity. | `PricingCard` |
| Objection card | Neutralize one conversion objection near the decision point. | `ObjectionCard` |
| Case card | Summarize problem, intervention, and result. | `CaseCard` |

## Usage Example

```tsx
import "./styles/clientverse-ui.css";
import { ButtonLink, FeatureCard, PricingCard } from "./components";

export function RevenueWorkflowSection() {
  return (
    <section>
      <ButtonLink href="/audit" variant="primary" size="lg" mobileFull>
        Request an Automation Audit
      </ButtonLink>

      <FeatureCard
        label="// RESPONSE CONTROL"
        title="Route qualified leads before response windows collapse."
        copy="ClientVerse identifies high-intent lead events, routes them into the correct follow-up path, and keeps the booking workflow visible to operators."
        badge="AI FOLLOW-UP"
        href="/services/response-control"
      />

      <PricingCard
        tier="Growth Command"
        fit="For teams that need AI follow-up, booking visibility, and revenue workflow control across multiple lead sources."
        price="$1,500+"
        featured
        badge="RECOMMENDED"
        ctaHref="/pricing/growth-command"
        features={[
          "Revenue workflow audit",
          "Lead capture and routing map",
          "AI follow-up deployment",
          "Booking and no-show recovery paths",
          "Dashboard visibility layer",
          "Monthly optimization review",
        ]}
      />
    </section>
  );
}
```

## Implementation Notes

The snippets intentionally avoid external component libraries so they can be adapted to Vite, Next.js, Remix, Astro, or a custom React setup. The CSS uses standard class names instead of framework-specific utilities, which makes the snippets easier to port into Tailwind, CSS Modules, vanilla CSS, or a design-token pipeline.

The snippets include accessibility fundamentals: visible focus states, disabled states, `aria-disabled` support for links, minimum mobile tap targets, reduced-motion behavior, and explicit support for icon-only button labels. Buttons and cards are deliberately restrained to avoid template SaaS styling, glowing AI visuals, cyberpunk effects, random gradients, or generic startup UI patterns.
